# README

Font available at http://losttype.com/klinic/ and is usable for Personal, Student or Non-profit use. 

Covers default set-up of SASS directory for an Omega 4.x subtheme.

I got kind of lazy with the partials/utility/abstractions/grid - they do import some stuff but I didn't think it necessary to reflect that in the chart.

## Source Files

Chart was created using Adobe Illustrator 5. I can provide versions for legacy if requested.

Zip file contains:

- SASS-Omega-Chart.png
- SASS Omega Chart.ai (font is intact and can be edited as long as it's installed)
- SASS Omega Chart--expandedfont.ai (font has been expanded so that it is usable for folks who do not have the font installed)
- Readme.txt